import React, { useRef, useState } from "react";
import "../styles/global.scss";
import {
  Card,
  CardMedia,
  CardContent,
  Alert,
  Typography,
  CardActions,
  Button,
  FormControl,
  Input,
  InputLabel,
} from "@mui/material";
import banner from "./../store/images/sign-in/sign-in-banner.png";
import { Container } from "@mui/system";
import { useFirebaseAuth } from "../contexts/FirebaseContext";
import { Link, useNavigate } from "react-router-dom";
import { Formik } from "formik";
import * as Yup from "yup";

const MIN_PASSWORD_CHARACTERS = 8;

const SignUpSchema = Yup.object().shape({
  email: Yup.string().email("Please check email").required(),
  password: Yup.string()
    .required()
    .matches(
      RegExp(
        `^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#a$%^&*])(?=.{${MIN_PASSWORD_CHARACTERS},})`
      ),
      "Password should be at least 8 characters long"
    ),
});

export default function SignIn() {
  const { signin } = useFirebaseAuth();
  const [error, setError] = useState("");
  const navigate = useNavigate();

  // Submit Profe
  const handleFormSubmit = async (email, password) => {
    // e.preventDefault();
    debugger;
    // console.log("values.email", values.email);
    console.log("email", email);
    console.log("email", email.current.value);
    // console.log("values.password", values.password);
    console.log("password", password);
    console.log("password", password.current.value);
    try {
      await signin(email, password);
    } catch (error) {
      setError(error, "Account creation failed");
    }
  };

  // async function handleSubmit(e) {
  //   e.preventDefault();

  //   if (passwordRef.current.value !== passwordConfirmationRef.current.value) {
  //     return setError("Passwords do not match");
  //   }

  //   try {
  //     setError("");
  //     setLoading(true);
  //     await signin(emailRef.current.value, passwordRef.current.value);
  //     navigate("/home");
  //   } catch {
  //     setError("Account creation failed");
  //   }

  //   setLoading(false);
  // }

  return (
    <main>
      <Formik
        initialValues={{ email: "", password: "" }}
        validationSchema={SignUpSchema}
        onSubmit={handleFormSubmit}
        validateOnBlur
        validateOnChange
        validateOnMount
      >
        {({
          values,
          errors,
          touched,
          handleSubmit,
          handleChange,
          handleBlur,
          isSubmitting,
          isValid,
          isValidating,
        }) => (
          <Card sx={{ minWidth: 345, maxWidth: 500 }}>
            <CardMedia
              component="img"
              height="140"
              image={banner}
              alt="pokemon banner"
            />
            <Container>
              <CardContent>
                <Typography gutterBottom variant="h5" component="div">
                  Enter a new account
                </Typography>
                {error && <Alert severity="error">{error}</Alert>}
                <form onSubmit={handleFormSubmit}>
                  <FormControl variant="standard" fullWidth={true}>
                    <InputLabel htmlFor="email">Email</InputLabel>
                    <Input
                      id="email"
                      type="email"
                      value={values.email}
                      onChange={handleChange("email")}
                      onBlur={handleBlur("email")}
                    />
                  </FormControl>
                  <br />
                  <FormControl variant="standard" fullWidth={true}>
                    <InputLabel htmlFor="password">Password</InputLabel>
                    <Input
                      id="password"
                      type="password"
                      value={values.password}
                      onChange={handleChange("password")}
                      onBlur={handleBlur("password")}
                    />
                  </FormControl>
                  <br />
                  {/* <FormControl variant="standard" fullWidth={true}>
                    <InputLabel htmlFor="confirmPassword">
                      Confirm Password
                    </InputLabel>
                    <Input
                      id="confirmPassword"
                      type="password"
                      value={values.passwordConfirmation}
                      onChange={handleChange("passwordConfirmation")}
                      onBlur={handleBlur("passwordConfirmation")}
                    />
                  </FormControl> */}
                  <Button
                    size="medium"
                    variant="contained"
                    type="submit"
                    style={{
                      marginTop: "1rem",
                    }}
                  >
                    Register
                  </Button>
                </form>
              </CardContent>
              <CardActions>
                <Typography variant="body2" color="text.secondary">
                  Already have an account?
                </Typography>
                <Button component={Link} to="/login" size="small">
                  Sign in here
                </Button>
              </CardActions>
            </Container>
          </Card>
        )}
      </Formik>
    </main>
  );
}
